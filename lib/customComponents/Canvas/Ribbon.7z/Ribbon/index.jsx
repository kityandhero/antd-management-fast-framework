import React, { PureComponent } from 'react';

class CanvasRibbon extends PureComponent {
  copyText = () => {
    const { canCopy, text } = this.props;

    if (canCopy && !stringIsNullOrWhiteSpace(text)) {
      copyToClipboard(text);
    }
  };

  render() {
    const { textPrefix, randomSeed, seedOffset, randomColor, color, text, canCopy } = this.props;

    let colorValue = color || '';

    const randomColorValue = randomColor || false;

    if (randomColorValue) {
      colorValue = getRandomColor(randomSeed + (isNumber(seedOffset) ? Math.abs(seedOffset) : 0));
    }

    const style = {
      ...{ color: 'rgba(0, 0, 0, 0.85)' },
      ...(canCopy ? { cursor: 'pointer' } : {}),
    };

    const textStyle = {
      ...(!stringIsNullOrWhiteSpace(colorValue) ? { color: colorValue } : {}),
    };

    return (
      <span
        style={style}
        onClick={() => {
          this.copyText();
        }}
      >
        {stringIsNullOrWhiteSpace(textPrefix) ? '' : `${textPrefix}：`}
        <span style={textStyle}>{text}</span>
      </span>
    );
  }
}

CanvasRibbon.defaultProps = {
  canCopy: false,
  randomSeed: 0,
  seedOffset: 0,
  randomColor: false,
  color: '',
  textPrefix: null,
  text: '',
};

export default CanvasRibbon;

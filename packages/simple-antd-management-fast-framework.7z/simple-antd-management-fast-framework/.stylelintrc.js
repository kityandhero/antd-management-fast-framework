let { generalConfig } = require('../../developConfig/stylelint/config');

module.exports = generalConfig;

window.appInitCustomLocal = {
  showLogInConsole: true,
  showRequestInfo: true,
  useVirtualRequest: true,
  showUseVirtualRequestMessage: true,
};

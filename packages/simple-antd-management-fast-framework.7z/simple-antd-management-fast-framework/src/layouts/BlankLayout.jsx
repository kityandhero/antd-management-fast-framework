const Layout = ({ children }) => <>{children}</>;

export default Layout;

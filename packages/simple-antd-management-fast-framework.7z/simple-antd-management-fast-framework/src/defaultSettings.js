/**
 * 占位函数
 *
 * @export
 * @returns
 */
export async function empty() {
  return {};
}

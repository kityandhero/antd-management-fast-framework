// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function parseUrlParamsForSetState({ urlParams }) {
  return {};
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function checkNeedUpdateAssist(
  currentState,
  preProps,
  preState,
  snapshot,
) {
  return false;
}

/**
 * 占位函数
 *
 * @export
 * @returns
 */
export async function empty() {
  return {};
}

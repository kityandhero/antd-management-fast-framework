let { generalConfig } = require('../../developConfig/eslint/config');

module.exports = generalConfig;

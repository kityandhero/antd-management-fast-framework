# Change Log

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.7.102](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.101...simple-antd-management-fast-framework@1.7.102) (2022-07-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.101](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.100...simple-antd-management-fast-framework@1.7.101) (2022-07-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.100](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.99...simple-antd-management-fast-framework@1.7.100) (2022-07-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.99](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.98...simple-antd-management-fast-framework@1.7.99) (2022-07-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.98](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.97...simple-antd-management-fast-framework@1.7.98) (2022-07-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.97](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.96...simple-antd-management-fast-framework@1.7.97) (2022-07-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.96](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.95...simple-antd-management-fast-framework@1.7.96) (2022-07-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.95](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.94...simple-antd-management-fast-framework@1.7.95) (2022-07-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.94](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.93...simple-antd-management-fast-framework@1.7.94) (2022-07-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.93](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.92...simple-antd-management-fast-framework@1.7.93) (2022-07-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.92](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.91...simple-antd-management-fast-framework@1.7.92) (2022-07-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.91](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.90...simple-antd-management-fast-framework@1.7.91) (2022-07-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.90](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.89...simple-antd-management-fast-framework@1.7.90) (2022-07-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.89](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.88...simple-antd-management-fast-framework@1.7.89) (2022-06-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.88](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.87...simple-antd-management-fast-framework@1.7.88) (2022-06-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.87](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.86...simple-antd-management-fast-framework@1.7.87) (2022-06-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.86](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.85...simple-antd-management-fast-framework@1.7.86) (2022-06-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.85](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.84...simple-antd-management-fast-framework@1.7.85) (2022-06-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.84](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.83...simple-antd-management-fast-framework@1.7.84) (2022-06-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.83](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.82...simple-antd-management-fast-framework@1.7.83) (2022-06-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.82](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.81...simple-antd-management-fast-framework@1.7.82) (2022-06-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.81](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.80...simple-antd-management-fast-framework@1.7.81) (2022-06-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.80](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.79...simple-antd-management-fast-framework@1.7.80) (2022-06-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.79](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.78...simple-antd-management-fast-framework@1.7.79) (2022-06-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.78](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.77...simple-antd-management-fast-framework@1.7.78) (2022-06-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.77](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.76...simple-antd-management-fast-framework@1.7.77) (2022-06-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.76](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.75...simple-antd-management-fast-framework@1.7.76) (2022-06-11)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.75](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.74...simple-antd-management-fast-framework@1.7.75) (2022-06-07)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.74](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.73...simple-antd-management-fast-framework@1.7.74) (2022-06-07)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.73](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.72...simple-antd-management-fast-framework@1.7.73) (2022-06-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.72](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.71...simple-antd-management-fast-framework@1.7.72) (2022-06-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.71](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.70...simple-antd-management-fast-framework@1.7.71) (2022-06-01)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.70](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.69...simple-antd-management-fast-framework@1.7.70) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.69](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.68...simple-antd-management-fast-framework@1.7.69) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.68](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.67...simple-antd-management-fast-framework@1.7.68) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.67](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.66...simple-antd-management-fast-framework@1.7.67) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.66](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.65...simple-antd-management-fast-framework@1.7.66) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.65](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.64...simple-antd-management-fast-framework@1.7.65) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.64](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.63...simple-antd-management-fast-framework@1.7.64) (2022-05-31)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.63](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.62...simple-antd-management-fast-framework@1.7.63) (2022-05-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.62](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.61...simple-antd-management-fast-framework@1.7.62) (2022-05-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.61](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.60...simple-antd-management-fast-framework@1.7.61) (2022-05-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.60](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.59...simple-antd-management-fast-framework@1.7.60) (2022-05-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.7.59](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.58...simple-antd-management-fast-framework@1.7.59) (2022-05-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.58](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.57...simple-antd-management-fast-framework@1.7.58) (2022-05-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.57](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.56...simple-antd-management-fast-framework@1.7.57) (2022-05-28)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.56](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.55...simple-antd-management-fast-framework@1.7.56) (2022-05-28)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.55](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.54...simple-antd-management-fast-framework@1.7.55) (2022-05-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.54](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.53...simple-antd-management-fast-framework@1.7.54) (2022-05-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.53](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.52...simple-antd-management-fast-framework@1.7.53) (2022-05-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.52](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.51...simple-antd-management-fast-framework@1.7.52) (2022-05-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.51](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.50...simple-antd-management-fast-framework@1.7.51) (2022-05-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.50](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.49...simple-antd-management-fast-framework@1.7.50) (2022-05-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.49](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.48...simple-antd-management-fast-framework@1.7.49) (2022-05-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.48](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.47...simple-antd-management-fast-framework@1.7.48) (2022-05-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.47](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.46...simple-antd-management-fast-framework@1.7.47) (2022-05-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.46](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.45...simple-antd-management-fast-framework@1.7.46) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.45](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.44...simple-antd-management-fast-framework@1.7.45) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.44](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.43...simple-antd-management-fast-framework@1.7.44) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.43](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.42...simple-antd-management-fast-framework@1.7.43) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.42](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.41...simple-antd-management-fast-framework@1.7.42) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.41](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.40...simple-antd-management-fast-framework@1.7.41) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.40](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.39...simple-antd-management-fast-framework@1.7.40) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.39](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.38...simple-antd-management-fast-framework@1.7.39) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.38](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.37...simple-antd-management-fast-framework@1.7.38) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.37](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.36...simple-antd-management-fast-framework@1.7.37) (2022-05-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.36](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.35...simple-antd-management-fast-framework@1.7.36) (2022-05-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.35](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.34...simple-antd-management-fast-framework@1.7.35) (2022-05-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.34](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.33...simple-antd-management-fast-framework@1.7.34) (2022-05-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.33](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.32...simple-antd-management-fast-framework@1.7.33) (2022-05-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.32](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.31...simple-antd-management-fast-framework@1.7.32) (2022-05-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.31](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.30...simple-antd-management-fast-framework@1.7.31) (2022-05-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.30](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.29...simple-antd-management-fast-framework@1.7.30) (2022-05-19)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.29](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.28...simple-antd-management-fast-framework@1.7.29) (2022-05-17)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.28](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.27...simple-antd-management-fast-framework@1.7.28) (2022-05-17)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.27](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.26...simple-antd-management-fast-framework@1.7.27) (2022-05-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.26](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.25...simple-antd-management-fast-framework@1.7.26) (2022-05-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.25](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.24...simple-antd-management-fast-framework@1.7.25) (2022-05-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.24](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.23...simple-antd-management-fast-framework@1.7.24) (2022-05-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.23](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.22...simple-antd-management-fast-framework@1.7.23) (2022-05-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.22](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.21...simple-antd-management-fast-framework@1.7.22) (2022-03-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.21](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.20...simple-antd-management-fast-framework@1.7.21) (2022-03-12)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.20](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.19...simple-antd-management-fast-framework@1.7.20) (2022-03-11)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.19](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.18...simple-antd-management-fast-framework@1.7.19) (2022-03-11)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.18](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.17...simple-antd-management-fast-framework@1.7.18) (2022-03-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.17](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.16...simple-antd-management-fast-framework@1.7.17) (2022-03-08)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.16](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.15...simple-antd-management-fast-framework@1.7.16) (2022-03-08)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.15](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.14...simple-antd-management-fast-framework@1.7.15) (2022-03-08)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.14](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.13...simple-antd-management-fast-framework@1.7.14) (2022-01-19)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.13](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.12...simple-antd-management-fast-framework@1.7.13) (2022-01-19)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.12](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.11...simple-antd-management-fast-framework@1.7.12) (2021-12-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.11](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.10...simple-antd-management-fast-framework@1.7.11) (2021-12-29)

### Performance Improvements

- **antd-management-fast-framework:** update ([0ae9427](https://github.com/kityandhero/antd-management-fast-framework/commit/0ae9427e7832c6b3014fd51814154612def06c78))

### [1.7.10](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.9...simple-antd-management-fast-framework@1.7.10) (2021-12-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.9](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.8...simple-antd-management-fast-framework@1.7.9) (2021-12-28)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.8](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.7...simple-antd-management-fast-framework@1.7.8) (2021-12-28)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.7](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.6...simple-antd-management-fast-framework@1.7.7) (2021-12-28)

### Performance Improvements

- update ([45e1d2e](https://github.com/kityandhero/antd-management-fast-framework/commit/45e1d2ea8ac446dee3ba12b31bcf9b52f442f8a2))

### [1.7.6](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.5...simple-antd-management-fast-framework@1.7.6) (2021-12-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.5](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.4...simple-antd-management-fast-framework@1.7.5) (2021-12-25)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.4](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.3...simple-antd-management-fast-framework@1.7.4) (2021-12-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.3](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.2...simple-antd-management-fast-framework@1.7.3) (2021-12-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.2](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.1...simple-antd-management-fast-framework@1.7.2) (2021-12-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.7.1](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.7.0...simple-antd-management-fast-framework@1.7.1) (2021-12-24)

### Performance Improvements

- update dependences ([735c080](https://github.com/kityandhero/antd-management-fast-framework/commit/735c080c3c07e4af7f696673642ae78bb7b820f9))

## [1.7.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.114...simple-antd-management-fast-framework@1.7.0) (2021-12-24)

### Features

- 手机预览增加 alert 提示组件，调整示例 ([7ab32c1](https://github.com/kityandhero/antd-management-fast-framework/commit/7ab32c1171c15670497ae6560490e59d86d47b94))

### [1.6.114](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.113...simple-antd-management-fast-framework@1.6.114) (2021-12-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.113](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.112...simple-antd-management-fast-framework@1.6.113) (2021-12-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.112](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.111...simple-antd-management-fast-framework@1.6.112) (2021-12-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.111](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.110...simple-antd-management-fast-framework@1.6.111) (2021-12-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.110](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.109...simple-antd-management-fast-framework@1.6.110) (2021-12-21)

### Performance Improvements

- update ([05403da](https://github.com/kityandhero/antd-management-fast-framework/commit/05403da1c4e2f9423e32a8ad2f4b7a765465dd60))

### [1.6.109](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.108...simple-antd-management-fast-framework@1.6.109) (2021-12-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.108](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.107...simple-antd-management-fast-framework@1.6.108) (2021-12-21)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.107](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.106...simple-antd-management-fast-framework@1.6.107) (2021-12-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.106](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.105...simple-antd-management-fast-framework@1.6.106) (2021-12-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.105](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.104...simple-antd-management-fast-framework@1.6.105) (2021-12-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.104](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.103...simple-antd-management-fast-framework@1.6.104) (2021-12-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.103](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.102...simple-antd-management-fast-framework@1.6.103) (2021-12-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.102](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.101...simple-antd-management-fast-framework@1.6.102) (2021-12-20)

### Performance Improvements

- update ([4387447](https://github.com/kityandhero/antd-management-fast-framework/commit/438744703d15de12eab72ac42e76c1e1b0d6734d))

### [1.6.101](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.100...simple-antd-management-fast-framework@1.6.101) (2021-12-18)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.100](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.99...simple-antd-management-fast-framework@1.6.100) (2021-12-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.99](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.98...simple-antd-management-fast-framework@1.6.99) (2021-12-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.98](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.97...simple-antd-management-fast-framework@1.6.98) (2021-12-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.97](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.96...simple-antd-management-fast-framework@1.6.97) (2021-12-15)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.96](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.95...simple-antd-management-fast-framework@1.6.96) (2021-12-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.95](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.94...simple-antd-management-fast-framework@1.6.95) (2021-12-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.94](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.93...simple-antd-management-fast-framework@1.6.94) (2021-12-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.93](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.92...simple-antd-management-fast-framework@1.6.93) (2021-12-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.92](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.91...simple-antd-management-fast-framework@1.6.92) (2021-12-14)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.91](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.90...simple-antd-management-fast-framework@1.6.91) (2021-12-11)

### Performance Improvements

- update ([be8b7ef](https://github.com/kityandhero/antd-management-fast-framework/commit/be8b7efd6bce55a10949f635263d4769313f777f))

### [1.6.90](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.89...simple-antd-management-fast-framework@1.6.90) (2021-12-11)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.89](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.88...simple-antd-management-fast-framework@1.6.89) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.88](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.87...simple-antd-management-fast-framework@1.6.88) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.87](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.86...simple-antd-management-fast-framework@1.6.87) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.86](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.85...simple-antd-management-fast-framework@1.6.86) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.85](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.84...simple-antd-management-fast-framework@1.6.85) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.84](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.83...simple-antd-management-fast-framework@1.6.84) (2021-12-10)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.83](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.82...simple-antd-management-fast-framework@1.6.83) (2021-12-09)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.82](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.81...simple-antd-management-fast-framework@1.6.82) (2021-12-08)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.81](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.80...simple-antd-management-fast-framework@1.6.81) (2021-12-07)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.80](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.79...simple-antd-management-fast-framework@1.6.80) (2021-12-07)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.79](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.78...simple-antd-management-fast-framework@1.6.79) (2021-12-07)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.78](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.77...simple-antd-management-fast-framework@1.6.78) (2021-12-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.77](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.76...simple-antd-management-fast-framework@1.6.77) (2021-12-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.76](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.75...simple-antd-management-fast-framework@1.6.76) (2021-12-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.75](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.74...simple-antd-management-fast-framework@1.6.75) (2021-12-04)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.74](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.73...simple-antd-management-fast-framework@1.6.74) (2021-12-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.73](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.72...simple-antd-management-fast-framework@1.6.73) (2021-12-02)

### Performance Improvements

- update ([730b6e1](https://github.com/kityandhero/antd-management-fast-framework/commit/730b6e1efb3fe9bebcde65b0c801405ca41b5c62))

### [1.6.72](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.71...simple-antd-management-fast-framework@1.6.72) (2021-12-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.71](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.70...simple-antd-management-fast-framework@1.6.71) (2021-12-01)

### Performance Improvements

- update ([48c5b3c](https://github.com/kityandhero/antd-management-fast-framework/commit/48c5b3ce4885532ebaea178c39235efd0905affc))

### [1.6.70](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.69...simple-antd-management-fast-framework@1.6.70) (2021-12-01)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.69](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.68...simple-antd-management-fast-framework@1.6.69) (2021-12-01)

### Performance Improvements

- adjust simple config ([667e36e](https://github.com/kityandhero/antd-management-fast-framework/commit/667e36e0ef29ea808ed4ec9d06c7f324ce186e71))

### [1.6.68](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.67...simple-antd-management-fast-framework@1.6.68) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.67](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.66...simple-antd-management-fast-framework@1.6.67) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.66](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.65...simple-antd-management-fast-framework@1.6.66) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.65](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.64...simple-antd-management-fast-framework@1.6.65) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.64](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.63...simple-antd-management-fast-framework@1.6.64) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.63](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.62...simple-antd-management-fast-framework@1.6.63) (2021-11-30)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.62](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.61...simple-antd-management-fast-framework@1.6.62) (2021-11-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.61](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.60...simple-antd-management-fast-framework@1.6.61) (2021-11-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.60](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.59...simple-antd-management-fast-framework@1.6.60) (2021-11-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.59](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.58...simple-antd-management-fast-framework@1.6.59) (2021-11-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.58](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.57...simple-antd-management-fast-framework@1.6.58) (2021-11-29)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.57](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.56...simple-antd-management-fast-framework@1.6.57) (2021-11-27)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.56](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.55...simple-antd-management-fast-framework@1.6.56) (2021-11-27)

### Bug Fixes

- **antd-management-fast-framework:** 列表视图增加分页栏固定配置 ([3ed968a](https://github.com/kityandhero/antd-management-fast-framework/commit/3ed968a0704c562cdeecbe1934683e7e361ded47))

### [1.6.55](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.54...simple-antd-management-fast-framework@1.6.55) (2021-11-26)

### Bug Fixes

- 调整配置 ([477f9ef](https://github.com/kityandhero/antd-management-fast-framework/commit/477f9ef91a106294287d95affc1b9df580cc738e))

### [1.6.54](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.53...simple-antd-management-fast-framework@1.6.54) (2021-11-26)

### Bug Fixes

- 调整配置 ([1b1a24e](https://github.com/kityandhero/antd-management-fast-framework/commit/1b1a24e969c5c834d1d070b26bf522423e910ce7))

### [1.6.53](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.52...simple-antd-management-fast-framework@1.6.53) (2021-11-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.52](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.51...simple-antd-management-fast-framework@1.6.52) (2021-11-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.51](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.50...simple-antd-management-fast-framework@1.6.51) (2021-11-26)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.50](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.49...simple-antd-management-fast-framework@1.6.50) (2021-11-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.49](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.48...simple-antd-management-fast-framework@1.6.49) (2021-11-24)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.48](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.47...simple-antd-management-fast-framework@1.6.48) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.47](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.46...simple-antd-management-fast-framework@1.6.47) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.46](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.45...simple-antd-management-fast-framework@1.6.46) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.45](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.44...simple-antd-management-fast-framework@1.6.45) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.44](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.43...simple-antd-management-fast-framework@1.6.44) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.43](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.42...simple-antd-management-fast-framework@1.6.43) (2021-11-23)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.42](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.41...simple-antd-management-fast-framework@1.6.42) (2021-11-23)

### Performance Improvements

- update ([524aca4](https://github.com/kityandhero/antd-management-fast-framework/commit/524aca45ed6da65b0e50127facd1f88a261b0cc0))

### [1.6.41](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.40...simple-antd-management-fast-framework@1.6.41) (2021-11-23)

### Performance Improvements

- update ([59033d1](https://github.com/kityandhero/antd-management-fast-framework/commit/59033d15c113b1e7dd7b1bdc6e026079c935c9de))

### [1.6.40](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.39...simple-antd-management-fast-framework@1.6.40) (2021-11-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.39](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.38...simple-antd-management-fast-framework@1.6.39) (2021-11-22)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.38](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.37...simple-antd-management-fast-framework@1.6.38) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.37](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.36...simple-antd-management-fast-framework@1.6.37) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.36](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.35...simple-antd-management-fast-framework@1.6.36) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.35](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.34...simple-antd-management-fast-framework@1.6.35) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.34](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.33...simple-antd-management-fast-framework@1.6.34) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.33](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.32...simple-antd-management-fast-framework@1.6.33) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.32](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.31...simple-antd-management-fast-framework@1.6.32) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.31](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.30...simple-antd-management-fast-framework@1.6.31) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.30](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.29...simple-antd-management-fast-framework@1.6.30) (2021-11-20)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.29](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.28...simple-antd-management-fast-framework@1.6.29) (2021-11-19)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.28](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.27...simple-antd-management-fast-framework@1.6.28) (2021-11-18)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.27](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.26...simple-antd-management-fast-framework@1.6.27) (2021-11-18)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.26](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.25...simple-antd-management-fast-framework@1.6.26) (2021-11-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.25](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.24...simple-antd-management-fast-framework@1.6.25) (2021-11-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.24](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.23...simple-antd-management-fast-framework@1.6.24) (2021-11-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.23](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.22...simple-antd-management-fast-framework@1.6.23) (2021-11-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.22](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.21...simple-antd-management-fast-framework@1.6.22) (2021-11-16)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.21](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.21) (2021-11-15)

### Performance Improvements

- update ([52ca489](https://github.com/kityandhero/antd-management-fast-framework/commit/52ca4896825cbefdf9f06574b0b7f3065f5dd0d1))
- update ([610da1c](https://github.com/kityandhero/antd-management-fast-framework/commit/610da1c84276626915d1c525d5e834bdc56f7ed2))
- update ([7035e0b](https://github.com/kityandhero/antd-management-fast-framework/commit/7035e0bd1140b4d1521e2392847fb6156e76a478))
- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.6.20](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.20) (2021-11-15)

### Performance Improvements

- update ([7035e0b](https://github.com/kityandhero/antd-management-fast-framework/commit/7035e0bd1140b4d1521e2392847fb6156e76a478))
- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.6.19](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.19) (2021-11-15)

### Performance Improvements

- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.6.18](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.18) (2021-11-15)

### Performance Improvements

- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.6.17](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.17) (2021-11-15)

### Performance Improvements

- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.6.16](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.15...simple-antd-management-fast-framework@1.6.16) (2021-11-15)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.15](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.14...simple-antd-management-fast-framework@1.6.15) (2021-11-13)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.14](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.13...simple-antd-management-fast-framework@1.6.14) (2021-11-13)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.13](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.12...simple-antd-management-fast-framework@1.6.13) (2021-11-13)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.12](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.11...simple-antd-management-fast-framework@1.6.12) (2021-11-13)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.11](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.10...simple-antd-management-fast-framework@1.6.11) (2021-11-12)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.10](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.9...simple-antd-management-fast-framework@1.6.10) (2021-11-09)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.9](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.8...simple-antd-management-fast-framework@1.6.9) (2021-11-09)

### Bug Fixes

- 调整显示 ([c5f4cc1](https://github.com/kityandhero/antd-management-fast-framework/commit/c5f4cc1ad460648b708ff2ed28a5ad6bbcd7c1af))

### [1.6.8](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.7...simple-antd-management-fast-framework@1.6.8) (2021-11-09)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.7](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.6...simple-antd-management-fast-framework@1.6.7) (2021-11-06)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.6](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.5...simple-antd-management-fast-framework@1.6.6) (2021-11-06)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.5](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.4...simple-antd-management-fast-framework@1.6.5) (2021-11-03)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.4](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.3...simple-antd-management-fast-framework@1.6.4) (2021-11-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.3](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.2...simple-antd-management-fast-framework@1.6.3) (2021-11-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.2](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.1...simple-antd-management-fast-framework@1.6.2) (2021-11-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

### [1.6.1](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.6.0...simple-antd-management-fast-framework@1.6.1) (2021-11-02)

**Note:** Version bump only for package simple-antd-management-fast-framework

## [1.6.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.6.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.5.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.5.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.4.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.4.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.3.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.3.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

# [1.2.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.2.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

# [1.1.0](https://github.com/kityandhero/antd-management-fast-framework/compare/simple-antd-management-fast-framework@1.0.169...simple-antd-management-fast-framework@1.1.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

var { generalConfig } = require('../../developConfig/prettier/config');

module.exports = generalConfig;

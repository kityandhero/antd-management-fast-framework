import React from 'react';

import {
  checkStringIsNullOrWhiteSpace,
  isUndefined,
  toNumber,
  transparentImage,
} from 'easy-soft-utility';

import { FlexBox, VerticalBox } from 'antd-management-fast-component';

import { CellMarker } from '../../CellMarker';
import {
  colorStyle,
  fontFamilyStyle,
  highlightModeCollection,
  labelFrontStyle,
  valueFrontStyle,
} from '../../constant';

function LineApply(properties) {
  const {
    general,
    data,
    currentName,
    spanColumn = 1,
    highlightMode,
    designMode,
    signetStyle,
    onClick: onClickCallback,
    onItemChange,
  } = properties;

  const { labelWidth } = { labelWidth: '0', ...general };

  const labelWidthAdjust =
    isUndefined(labelWidth) ||
    checkStringIsNullOrWhiteSpace(labelWidth) ||
    toNumber(labelWidth) <= 0
      ? ''
      : labelWidth;

  const { title, note, name, signet, time } = {
    title: '',
    note: '',
    name: '',
    signet: '',
    time: '',
    ...data,
  };

  return (
    <tr>
      <td
        style={{
          position: 'relative',
          ...labelFrontStyle,
          ...fontFamilyStyle,
          textAlign: 'center',
          width: `${labelWidthAdjust}px`,
        }}
      >
        {designMode ? (
          <CellMarker
            useHover={false}
            data={{ title, name }}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.label
            }
            highlightMode={highlightModeCollection.label}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        {title}
      </td>

      <td
        style={{
          position: 'relative',
          paddingLeft: '10px',
          paddingRight: '10px',
        }}
        colSpan={spanColumn}
      >
        {designMode ? (
          <CellMarker
            useHover={false}
            data={{ title, name }}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.value
            }
            highlightMode={highlightModeCollection.value}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        <VerticalBox fillWidth>
          <div style={{ width: '100%' }}>
            {checkStringIsNullOrWhiteSpace(note) ? (
              <div
                style={{ padding: '3px 0 5px 0' }}
                dangerouslySetInnerHTML={{ __html: '&nbsp;' }}
              ></div>
            ) : (
              <div
                style={{
                  padding: '3px 0 5px 0',
                  ...valueFrontStyle,
                  ...colorStyle,
                  ...fontFamilyStyle,
                }}
              >
                {note}
              </div>
            )}

            <div style={{ padding: '0px 0 5px 0' }}>
              <FlexBox
                flexAuto="left"
                left={<div></div>}
                right={
                  <div>
                    <FlexBox
                      flexAuto="left"
                      left={
                        <div style={{ height: '40px', position: 'relative' }}>
                          <img
                            src={signet || transparentImage}
                            style={{
                              height: '40px',
                              top: '0',
                              ...signetStyle,
                              right: '0',
                              position: 'absolute',
                            }}
                          />
                        </div>
                      }
                      rightStyle={{
                        paddingLeft: '10px',
                        paddingRight: '10px',
                      }}
                      right={
                        <div
                          style={{
                            fontSize: '18px',
                            fontWeight: 'normal',
                            lineHeight: '40px',
                            ...fontFamilyStyle,
                          }}
                        >
                          {time}
                        </div>
                      }
                    />
                  </div>
                }
              />
            </div>
          </div>
        </VerticalBox>
      </td>
    </tr>
  );
}

export { LineApply };

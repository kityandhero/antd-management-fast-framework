import React from 'react';

import {
  checkStringIsNullOrWhiteSpace,
  isUndefined,
  toNumber,
} from 'easy-soft-utility';

import { CellMarker } from '../../CellMarker';
import {
  colorStyle,
  fontFamilyStyle,
  highlightModeCollection,
  labelFrontStyle,
  valueFrontStyle,
} from '../../constant';

function LineRemark(properties) {
  const {
    general,
    title,
    name,
    value,
    currentName,
    spanColumn = 1,
    highlightMode,
    designMode,
    valueBoxStyle,
    onClick: onClickCallback,
    onItemChange,
  } = properties;

  const { labelWidth } = { labelWidth: '0', ...general };

  const labelWidthAdjust =
    isUndefined(labelWidth) ||
    checkStringIsNullOrWhiteSpace(labelWidth) ||
    toNumber(labelWidth) <= 0
      ? ''
      : labelWidth;

  return (
    <tr>
      <td
        style={{
          ...labelFrontStyle,
          ...fontFamilyStyle,
          textAlign: 'center',
          width: `${labelWidthAdjust}px`,
          position: 'relative',
        }}
      >
        {designMode ? (
          <CellMarker
            useHover={false}
            data={{ title, name }}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.label
            }
            highlightMode={highlightModeCollection.label}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        {title}
      </td>

      <td
        style={{
          paddingLeft: '10px',
          paddingRight: '10px',
          ...valueFrontStyle,
          ...colorStyle,
          ...fontFamilyStyle,
          ...valueBoxStyle,
          position: 'relative',
        }}
        colSpan={spanColumn}
      >
        {designMode ? (
          <CellMarker
            useHover={false}
            data={{ title, name }}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.value
            }
            highlightMode={highlightModeCollection.value}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        {value}
      </td>
    </tr>
  );

  // return (
  //   <FlexBox
  //     flexAuto="right"
  //     style={{
  //       ...lineStyle,
  //       ...(checkStringIsNullOrWhiteSpace(minHeightAdjust)
  //         ? {}
  //         : {
  //             minHeight: `${toNumber(minHeightAdjust)}px`,
  //           }),
  //       overflow: 'hidden',
  //     }}
  //     leftStyle={{
  //       ...labelBoxStyle,
  //       position: 'relative',
  //       padding: '0',
  //       ...(checkStringIsNullOrWhiteSpace(minHeightAdjust)
  //         ? {}
  //         : {
  //             minHeight: `${toNumber(minHeightAdjust)}px`,
  //           }),
  //       ...(checkStringIsNullOrWhiteSpace(labelWidthAdjust)
  //         ? {}
  //         : {
  //             width: `${labelWidthAdjust}px`,
  //           }),
  //     }}
  //     left={
  //       <>
  //         {designMode ? (
  //           <CellMarker
  //             useHover={false}
  //             data={{ title, name }}
  //             highlight={
  //               currentName === name &&
  //               highlightMode === highlightModeCollection.none
  //             }
  //             highlightMode={highlightModeCollection.none}
  //           />
  //         ) : null}

  //         <div
  //           style={{
  //             labelBoxStyle,
  //             height: '100%',
  //             ...(checkStringIsNullOrWhiteSpace(minHeightAdjust)
  //               ? {}
  //               : {
  //                   minHeight: `${toNumber(minHeightAdjust)}px`,
  //                 }),
  //           }}
  //         >
  //           <CenterBox>
  //             <div style={labelContainerStyle}>{title}</div>
  //           </CenterBox>
  //         </div>
  //       </>
  //     }
  //     rightStyle={{
  //       ...valueBoxStyle,
  //       ...(checkStringIsNullOrWhiteSpace(minHeightAdjust)
  //         ? {}
  //         : {
  //             minHeight: `${toNumber(minHeightAdjust)}px`,
  //           }),
  //     }}
  //     right={
  //       <div
  //         style={{
  //           ...valueContainerStyle,
  //           position: 'relative',
  //           width: '100%',
  //           height: '100%',
  //         }}
  //       >
  //         {designMode ? (
  //           <CellMarker
  //             useHover={false}
  //             data={{ title, name }}
  //             highlight={
  //               currentName === name &&
  //               highlightMode === highlightModeCollection.none
  //             }
  //             highlightMode={highlightModeCollection.none}
  //           />
  //         ) : null}

  //         <div
  //           style={{
  //             width: '100%',
  //             height: '100%',
  //           }}
  //         >
  //           <div
  //             style={{
  //               paddingLeft: '10px',
  //               paddingRight: '10px',
  //               height: '100%',
  //             }}
  //           >
  //             <VerticalBox>
  //               <div>{value}</div>
  //             </VerticalBox>
  //           </div>
  //         </div>
  //       </div>
  //     }
  //   />
  // );
}

export { LineRemark };

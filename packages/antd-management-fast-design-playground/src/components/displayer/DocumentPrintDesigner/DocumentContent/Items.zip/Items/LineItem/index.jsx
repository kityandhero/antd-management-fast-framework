import React from 'react';

import {
  checkStringIsNullOrWhiteSpace,
  isArray,
  isUndefined,
  toNumber,
  whetherNumber,
} from 'easy-soft-utility';

import { CellMarker } from '../../CellMarker';
import {
  colorStyle,
  defaultConfig,
  fontFamilyStyle,
  highlightModeCollection,
  valueFrontStyle,
} from '../../constant';
import { buildDisplayValue } from '../../tools';
import { InLineItem } from '../InLineItem';

function LineItem(properties) {
  const {
    general,
    data,
    values,
    currentName,
    highlightMode,
    designMode,
    lineStyle,
    labelBoxStyle,
    valueBoxStyle,
    labelContainerStyle,
    valueContainerStyle,
    onClick: onClickCallback,
    onItemChange,
  } = properties;

  let dataAdjust;
  let otherList = [];

  if (isArray(data)) {
    if (data.length <= 0) {
      return null;
    } else {
      dataAdjust = data.shift();

      otherList = [...data];
    }
  } else {
    dataAdjust = data;
  }

  const {
    fullLine,
    title,
    name,
    labelWidth,
    valueWidth,
    labelSpanRow,
    labelSpanColumn,
    valueSpanRow,
    valueSpanColumn,
  } = {
    fullLine: defaultConfig.fullLine,
    title: '',
    name: '',
    labelWidth: defaultConfig.labelWidth,
    valueWidth: defaultConfig.valueWidth,
    labelSpanRow: defaultConfig.labelSpanRow,
    labelSpanColumn: defaultConfig.labelSpanColumn,
    valueSpanRow: defaultConfig.valueSpanRow,
    valueSpanColumn: defaultConfig.valueSpanColumn,
    ...dataAdjust,
  };

  const fullLineAdjust = toNumber(fullLine);

  const labelWidthAdjust =
    isUndefined(labelWidth) ||
    checkStringIsNullOrWhiteSpace(labelWidth) ||
    toNumber(labelWidth) <= 0
      ? ''
      : labelWidth;

  const valueWidthAdjust =
    isUndefined(valueWidth) ||
    checkStringIsNullOrWhiteSpace(valueWidth) ||
    toNumber(valueWidth) <= 0
      ? ''
      : valueWidth;

  const labelSpanRowAdjust =
    isUndefined(labelSpanRow) ||
    checkStringIsNullOrWhiteSpace(labelSpanRow) ||
    toNumber(labelSpanRow) <= 0
      ? defaultConfig.labelSpanRow
      : labelSpanRow;

  const labelSpanColumnAdjust =
    isUndefined(labelSpanColumn) ||
    checkStringIsNullOrWhiteSpace(labelSpanColumn) ||
    toNumber(labelSpanColumn) <= 0
      ? defaultConfig.labelSpanColumn
      : labelSpanColumn;

  const valueSpanRowAdjust =
    isUndefined(valueSpanRow) ||
    checkStringIsNullOrWhiteSpace(valueSpanRow) ||
    toNumber(valueSpanRow) <= 0
      ? defaultConfig.valueSpanRow
      : valueSpanRow;

  const valueSpanColumnAdjust =
    isUndefined(valueSpanColumn) ||
    checkStringIsNullOrWhiteSpace(valueSpanColumn) ||
    toNumber(valueSpanColumn) <= 0
      ? defaultConfig.valueSpanColumn
      : valueSpanColumn;

  const { globalLabelWidth, globalMinHeight } = {
    globalLabelWidth: '0',
    globalMinHeight: defaultConfig.globalMinHeight,
    ...general,
  };

  const globalLabelWidthAdjust =
    isUndefined(globalLabelWidth) ||
    checkStringIsNullOrWhiteSpace(globalLabelWidth) ||
    toNumber(globalLabelWidth) <= 0
      ? toNumber(defaultConfig.globalLabelWidth)
      : toNumber(globalLabelWidth);

  const globalMinHeightAdjust =
    isUndefined(globalMinHeight) ||
    checkStringIsNullOrWhiteSpace(globalMinHeight) ||
    toNumber(globalMinHeight) <= 0
      ? toNumber(defaultConfig.globalMinHeight)
      : toNumber(globalMinHeight);

  const displayValue = buildDisplayValue(dataAdjust, values);

  return (
    <tr>
      <td
        style={{
          position: 'relative',
          ...(fullLineAdjust === whetherNumber.yes
            ? {
                width: `${globalLabelWidthAdjust}px`,
              }
            : labelWidthAdjust > 0
              ? {
                  width: `${labelWidthAdjust}px`,
                }
              : {}),
        }}
        rowSpan={
          fullLineAdjust === whetherNumber.yes ? '1' : labelSpanRowAdjust
        }
        colSpan={
          fullLineAdjust === whetherNumber.yes ? '1' : labelSpanColumnAdjust
        }
      >
        {designMode ? (
          <CellMarker
            data={dataAdjust}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.label
            }
            highlightMode={highlightModeCollection.label}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        <div
          style={{
            width: '100%',
            height: '100%',
            ...valueFrontStyle,
            ...colorStyle,
            ...fontFamilyStyle,
            ...labelBoxStyle,
            borderRight: '0',
          }}
        >
          <div
            style={{
              ...labelContainerStyle,
            }}
          >
            {title}
          </div>
        </div>
      </td>

      <td
        style={{
          position: 'relative',
          ...(fullLineAdjust === whetherNumber.yes
            ? {}
            : valueWidthAdjust > 0
              ? {
                  width: `${valueWidthAdjust}px`,
                }
              : {}),
        }}
        rowSpan={
          fullLineAdjust === whetherNumber.yes ? '1' : valueSpanRowAdjust
        }
        colSpan={
          fullLineAdjust === whetherNumber.yes ? '1' : valueSpanColumnAdjust
        }
      >
        {designMode ? (
          <CellMarker
            data={dataAdjust}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.value
            }
            highlightMode={highlightModeCollection.value}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        <div
          style={{
            width: '100%',
            height: '100%',
            ...valueFrontStyle,
            ...colorStyle,
            ...fontFamilyStyle,
            ...valueBoxStyle,
            borderRight: '0',
          }}
        >
          <div
            style={{
              paddingLeft: '10px',
              paddingRight: '10px',
              height: '100%',
            }}
          >
            {displayValue}
          </div>
        </div>
      </td>

      {otherList.map((o, columnIndex) => {
        return (
          <InLineItem
            key={`line_column_${columnIndex}`}
            designMode={designMode}
            values={values}
            data={o}
            currentName={currentName}
            highlightMode={highlightMode}
            labelBoxStyle={labelBoxStyle}
            labelContainerStyle={labelContainerStyle}
            valueBoxStyle={valueBoxStyle}
            onClick={onClickCallback}
            onItemChange={onItemChange}
          />
        );
      })}
    </tr>
  );
}

export { LineItem };

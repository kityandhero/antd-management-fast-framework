import React from 'react';

import {
  checkStringIsNullOrWhiteSpace,
  isUndefined,
  toNumber,
} from 'easy-soft-utility';

import { CenterBox } from 'antd-management-fast-component';

import { CellMarker } from '../../CellMarker';
import {
  colorStyle,
  defaultConfig,
  fontFamilyStyle,
  highlightModeCollection,
  labelFrontStyle,
  valueFrontStyle,
} from '../../constant';
import { buildDisplayValue } from '../../tools';

function InLineItem(properties) {
  const {
    data,
    values,
    currentName,
    highlightMode,
    labelBoxStyle,
    labelContainerStyle,
    valueBoxStyle,
    designMode,
    onItemChange,
    onClick: onClickCallback,
  } = properties;

  const {
    title,
    name,
    labelWidth,
    valueWidth,
    labelSpanRow,
    labelSpanColumn,
    valueSpanRow,
    valueSpanColumn,
  } = {
    labelWidth: defaultConfig.labelWidth,
    valueWidth: defaultConfig.valueWidth,
    labelSpanRow: defaultConfig.labelSpanRow,
    labelSpanColumn: defaultConfig.labelSpanColumn,
    valueSpanRow: defaultConfig.valueSpanRow,
    valueSpanColumn: defaultConfig.valueSpanColumn,
    ...data,
  };

  const displayValue = buildDisplayValue(data, values);

  const labelWidthAdjust =
    isUndefined(labelWidth) ||
    checkStringIsNullOrWhiteSpace(labelWidth) ||
    toNumber(labelWidth) <= 0
      ? ''
      : labelWidth;

  const valueWidthAdjust =
    isUndefined(valueWidth) ||
    checkStringIsNullOrWhiteSpace(valueWidth) ||
    toNumber(valueWidth) <= 0
      ? ''
      : valueWidth;

  const labelSpanRowAdjust =
    isUndefined(labelSpanRow) ||
    checkStringIsNullOrWhiteSpace(labelSpanRow) ||
    toNumber(labelSpanRow) <= 0
      ? defaultConfig.labelSpanRow
      : labelSpanRow;

  const labelSpanColumnAdjust =
    isUndefined(labelSpanColumn) ||
    checkStringIsNullOrWhiteSpace(labelSpanColumn) ||
    toNumber(labelSpanColumn) <= 0
      ? defaultConfig.labelSpanColumn
      : labelSpanColumn;

  const valueSpanRowAdjust =
    isUndefined(valueSpanRow) ||
    checkStringIsNullOrWhiteSpace(valueSpanRow) ||
    toNumber(valueSpanRow) <= 0
      ? defaultConfig.valueSpanRow
      : valueSpanRow;

  const valueSpanColumnAdjust =
    isUndefined(valueSpanColumn) ||
    checkStringIsNullOrWhiteSpace(valueSpanColumn) ||
    toNumber(valueSpanColumn) <= 0
      ? defaultConfig.valueSpanColumn
      : valueSpanColumn;

  const filedComponent = (
    <>
      <td
        style={{
          position: 'relative',
          ...(labelWidthAdjust > 0
            ? {
                width: `${labelWidthAdjust}px`,
              }
            : {}),
        }}
        rowSpan={labelSpanRowAdjust}
        colSpan={labelSpanColumnAdjust}
      >
        {designMode ? (
          <CellMarker
            data={data}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.label
            }
            highlightMode={highlightModeCollection.label}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        <div
          style={{
            paddingTop: '12px',
            paddingBottom: '12px',
            paddingLeft: '10px',
            paddingRight: '10px',
            textAlign: 'center',
            ...labelFrontStyle,
            ...colorStyle,
            ...fontFamilyStyle,
            ...labelBoxStyle,
            width: 'auto',
          }}
        >
          <CenterBox>
            <div
              style={{
                paddingLeft: '6px',
                paddingRight: '6px',
                ...labelContainerStyle,
                whiteSpace: 'nowrap',
              }}
            >
              {title}
            </div>
          </CenterBox>
        </div>
      </td>

      <td
        style={{
          position: 'relative',
          ...(valueWidthAdjust > 0
            ? {
                width: `${valueWidthAdjust}px`,
              }
            : {}),
        }}
        rowSpan={valueSpanRowAdjust}
        colSpan={valueSpanColumnAdjust}
      >
        {designMode ? (
          <CellMarker
            data={data}
            highlight={
              currentName === name &&
              highlightMode === highlightModeCollection.value
            }
            highlightMode={highlightModeCollection.value}
            onItemChange={onItemChange}
            onClick={onClickCallback}
          />
        ) : null}

        <div
          style={{
            width: '100%',
            height: '100%',
            ...valueFrontStyle,
            ...colorStyle,
            ...fontFamilyStyle,
            ...valueBoxStyle,
            borderRight: '0',
          }}
        >
          <div
            style={{
              paddingLeft: '10px',
              paddingRight: '10px',
              height: '100%',
            }}
          >
            {displayValue}
          </div>
        </div>
      </td>
    </>
  );

  return filedComponent;
}

export { InLineItem };

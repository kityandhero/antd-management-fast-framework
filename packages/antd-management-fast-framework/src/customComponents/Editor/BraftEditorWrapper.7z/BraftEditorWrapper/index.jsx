import React, { PureComponent } from 'react';
import BraftEditor from 'braft-editor';
import 'braft-editor/dist/index.css';

import { isFunction } from '../../../utils/tools';

class BraftEditorWrapper extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      initContent: '',
      editorState: null,
    };
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  static getDerivedStateFromProps(nextProps, prevState) {
    const { editorState, initContent: contentPrev } = prevState;
    const { content: contentNext } = nextProps;

    if (contentPrev !== contentNext || editorState == null) {
      return {
        initContent: contentNext,
        editorState: BraftEditor.createEditorState(contentNext || ''),
      };
    }

    return {};
  }

  handleEditorChange = (editorState) => {
    const { afterChange } = this.props;

    this.setState({ editorState });

    if (isFunction(afterChange)) {
      afterChange(editorState.toHTML());
    }
  };

  render() {
    const { editorState } = this.state;

    return (
      <div
        style={{
          border: '1px solid #ccc',
        }}
      >
        <BraftEditor
          placeholder="请在此编辑您所需要的内容!"
          value={editorState}
          onChange={this.handleEditorChange}
        />
      </div>
    );
  }
}

BraftEditorWrapper.defaultProps = {
  content: '',
};

export default BraftEditorWrapper;

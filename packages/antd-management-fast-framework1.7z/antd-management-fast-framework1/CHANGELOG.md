# Change Log

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.12.103](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.102...antd-management-fast-framework@1.12.103) (2022-07-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.102](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.101...antd-management-fast-framework@1.12.102) (2022-07-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.101](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.100...antd-management-fast-framework@1.12.101) (2022-07-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.100](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.99...antd-management-fast-framework@1.12.100) (2022-07-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.99](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.98...antd-management-fast-framework@1.12.99) (2022-07-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.98](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.97...antd-management-fast-framework@1.12.98) (2022-07-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.97](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.96...antd-management-fast-framework@1.12.97) (2022-07-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.96](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.95...antd-management-fast-framework@1.12.96) (2022-07-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.95](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.94...antd-management-fast-framework@1.12.95) (2022-07-14)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.94](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.93...antd-management-fast-framework@1.12.94) (2022-07-10)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.93](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.92...antd-management-fast-framework@1.12.93) (2022-07-10)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.92](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.91...antd-management-fast-framework@1.12.92) (2022-07-04)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.91](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.90...antd-management-fast-framework@1.12.91) (2022-07-04)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.90](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.89...antd-management-fast-framework@1.12.90) (2022-06-29)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.89](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.88...antd-management-fast-framework@1.12.89) (2022-06-29)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.88](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.87...antd-management-fast-framework@1.12.88) (2022-06-29)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.87](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.86...antd-management-fast-framework@1.12.87) (2022-06-27)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.86](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.85...antd-management-fast-framework@1.12.86) (2022-06-27)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.85](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.84...antd-management-fast-framework@1.12.85) (2022-06-27)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.84](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.83...antd-management-fast-framework@1.12.84) (2022-06-25)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.83](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.82...antd-management-fast-framework@1.12.83) (2022-06-25)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.82](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.81...antd-management-fast-framework@1.12.82) (2022-06-25)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.81](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.80...antd-management-fast-framework@1.12.81) (2022-06-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.80](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.79...antd-management-fast-framework@1.12.80) (2022-06-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.79](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.78...antd-management-fast-framework@1.12.79) (2022-06-22)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.78](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.77...antd-management-fast-framework@1.12.78) (2022-06-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.77](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.76...antd-management-fast-framework@1.12.77) (2022-06-21)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.76](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.75...antd-management-fast-framework@1.12.76) (2022-06-11)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.75](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.74...antd-management-fast-framework@1.12.75) (2022-06-07)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.74](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.73...antd-management-fast-framework@1.12.74) (2022-06-07)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.73](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.72...antd-management-fast-framework@1.12.73) (2022-06-02)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.72](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.71...antd-management-fast-framework@1.12.72) (2022-06-02)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.71](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.70...antd-management-fast-framework@1.12.71) (2022-06-01)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.70](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.69...antd-management-fast-framework@1.12.70) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.69](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.68...antd-management-fast-framework@1.12.69) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.68](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.67...antd-management-fast-framework@1.12.68) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.67](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.66...antd-management-fast-framework@1.12.67) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.66](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.65...antd-management-fast-framework@1.12.66) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.65](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.64...antd-management-fast-framework@1.12.65) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.64](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.63...antd-management-fast-framework@1.12.64) (2022-05-31)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.63](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.62...antd-management-fast-framework@1.12.63) (2022-05-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.62](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.61...antd-management-fast-framework@1.12.62) (2022-05-30)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.61](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.60...antd-management-fast-framework@1.12.61) (2022-05-29)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.60](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.59...antd-management-fast-framework@1.12.60) (2022-05-29)

**Note:** Version bump only for package antd-management-fast-framework

## [1.12.59](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.58...antd-management-fast-framework@1.12.59) (2022-05-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.58](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.57...antd-management-fast-framework@1.12.58) (2022-05-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.57](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.56...antd-management-fast-framework@1.12.57) (2022-05-28)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.56](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.55...antd-management-fast-framework@1.12.56) (2022-05-28)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.55](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.54...antd-management-fast-framework@1.12.55) (2022-05-27)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.54](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.53...antd-management-fast-framework@1.12.54) (2022-05-27)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.53](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.52...antd-management-fast-framework@1.12.53) (2022-05-27)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.52](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.51...antd-management-fast-framework@1.12.52) (2022-05-26)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.51](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.50...antd-management-fast-framework@1.12.51) (2022-05-26)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.50](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.49...antd-management-fast-framework@1.12.50) (2022-05-26)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.49](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.48...antd-management-fast-framework@1.12.49) (2022-05-25)

### Performance Improvements

- **antd-management-fast-cli:** update ([e28f8a9](https://github.com/kityandhero/antd-management-fast-framework/commit/e28f8a9ac4bc47dfe0fde35a1548cd8925f5bbd5))

### [1.12.48](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.47...antd-management-fast-framework@1.12.48) (2022-05-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.47](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.46...antd-management-fast-framework@1.12.47) (2022-05-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.46](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.45...antd-management-fast-framework@1.12.46) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.45](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.44...antd-management-fast-framework@1.12.45) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.44](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.43...antd-management-fast-framework@1.12.44) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.43](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.42...antd-management-fast-framework@1.12.43) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.42](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.41...antd-management-fast-framework@1.12.42) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.41](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.40...antd-management-fast-framework@1.12.41) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.40](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.39...antd-management-fast-framework@1.12.40) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.39](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.38...antd-management-fast-framework@1.12.39) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.38](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.37...antd-management-fast-framework@1.12.38) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.37](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.36...antd-management-fast-framework@1.12.37) (2022-05-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.36](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.35...antd-management-fast-framework@1.12.36) (2022-05-22)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.35](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.34...antd-management-fast-framework@1.12.35) (2022-05-22)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.34](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.33...antd-management-fast-framework@1.12.34) (2022-05-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.33](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.32...antd-management-fast-framework@1.12.33) (2022-05-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.32](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.31...antd-management-fast-framework@1.12.32) (2022-05-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.31](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.30...antd-management-fast-framework@1.12.31) (2022-05-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.30](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.29...antd-management-fast-framework@1.12.30) (2022-05-19)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.29](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.28...antd-management-fast-framework@1.12.29) (2022-05-17)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.28](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.27...antd-management-fast-framework@1.12.28) (2022-05-17)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.27](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.26...antd-management-fast-framework@1.12.27) (2022-05-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.26](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.25...antd-management-fast-framework@1.12.26) (2022-05-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.25](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.24...antd-management-fast-framework@1.12.25) (2022-05-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.24](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.23...antd-management-fast-framework@1.12.24) (2022-05-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.23](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.22...antd-management-fast-framework@1.12.23) (2022-05-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.22](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.21...antd-management-fast-framework@1.12.22) (2022-03-22)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.21](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.20...antd-management-fast-framework@1.12.21) (2022-03-12)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.20](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.19...antd-management-fast-framework@1.12.20) (2022-03-11)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.19](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.18...antd-management-fast-framework@1.12.19) (2022-03-11)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.18](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.17...antd-management-fast-framework@1.12.18) (2022-03-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.17](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.16...antd-management-fast-framework@1.12.17) (2022-03-08)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.16](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.15...antd-management-fast-framework@1.12.16) (2022-03-08)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.15](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.14...antd-management-fast-framework@1.12.15) (2022-03-08)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.14](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.13...antd-management-fast-framework@1.12.14) (2022-01-19)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.13](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.12...antd-management-fast-framework@1.12.13) (2022-01-19)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.12](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.11...antd-management-fast-framework@1.12.12) (2021-12-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.11](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.10...antd-management-fast-framework@1.12.11) (2021-12-29)

### Performance Improvements

- **antd-management-fast-framework:** update ([0ae9427](https://github.com/kityandhero/antd-management-fast-framework/commit/0ae9427e7832c6b3014fd51814154612def06c78))

### [1.12.10](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.9...antd-management-fast-framework@1.12.10) (2021-12-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.9](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.8...antd-management-fast-framework@1.12.9) (2021-12-28)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.8](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.7...antd-management-fast-framework@1.12.8) (2021-12-28)

### Performance Improvements

- **antd-management-fast-framework:** update ([344a956](https://github.com/kityandhero/antd-management-fast-framework/commit/344a9564dd868d5b38197cecf521ecc475a85f68))

### [1.12.7](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.6...antd-management-fast-framework@1.12.7) (2021-12-28)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.6](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.5...antd-management-fast-framework@1.12.6) (2021-12-25)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.5](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.4...antd-management-fast-framework@1.12.5) (2021-12-25)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.4](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.3...antd-management-fast-framework@1.12.4) (2021-12-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.3](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.2...antd-management-fast-framework@1.12.3) (2021-12-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.2](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.1...antd-management-fast-framework@1.12.2) (2021-12-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.12.1](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.12.0...antd-management-fast-framework@1.12.1) (2021-12-24)

### Performance Improvements

- update dependences ([735c080](https://github.com/kityandhero/antd-management-fast-framework/commit/735c080c3c07e4af7f696673642ae78bb7b820f9))

## [1.12.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.62...antd-management-fast-framework@1.12.0) (2021-12-24)

### Features

- 手机预览增加 alert 提示组件，调整示例 ([7ab32c1](https://github.com/kityandhero/antd-management-fast-framework/commit/7ab32c1171c15670497ae6560490e59d86d47b94))

### [1.11.62](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.61...antd-management-fast-framework@1.11.62) (2021-12-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.61](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.60...antd-management-fast-framework@1.11.61) (2021-12-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.60](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.59...antd-management-fast-framework@1.11.60) (2021-12-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.59](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.58...antd-management-fast-framework@1.11.59) (2021-12-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.58](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.57...antd-management-fast-framework@1.11.58) (2021-12-21)

### Performance Improvements

- update ([05403da](https://github.com/kityandhero/antd-management-fast-framework/commit/05403da1c4e2f9423e32a8ad2f4b7a765465dd60))

### [1.11.57](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.56...antd-management-fast-framework@1.11.57) (2021-12-21)

### Performance Improvements

- update ([c8dde44](https://github.com/kityandhero/antd-management-fast-framework/commit/c8dde4432d5aa6d4c1f14c9344321dcd28540eff))

### [1.11.56](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.55...antd-management-fast-framework@1.11.56) (2021-12-21)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.55](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.54...antd-management-fast-framework@1.11.55) (2021-12-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.54](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.53...antd-management-fast-framework@1.11.54) (2021-12-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.53](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.52...antd-management-fast-framework@1.11.53) (2021-12-20)

### Performance Improvements

- update ([baa136e](https://github.com/kityandhero/antd-management-fast-framework/commit/baa136ef113aad808eda34555811dae509498e8d))

### [1.11.52](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.51...antd-management-fast-framework@1.11.52) (2021-12-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.51](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.50...antd-management-fast-framework@1.11.51) (2021-12-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.50](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.49...antd-management-fast-framework@1.11.50) (2021-12-20)

### Performance Improvements

- update ([4387447](https://github.com/kityandhero/antd-management-fast-framework/commit/438744703d15de12eab72ac42e76c1e1b0d6734d))

### [1.11.49](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.48...antd-management-fast-framework@1.11.49) (2021-12-18)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.48](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.47...antd-management-fast-framework@1.11.48) (2021-12-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.47](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.46...antd-management-fast-framework@1.11.47) (2021-12-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.46](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.45...antd-management-fast-framework@1.11.46) (2021-12-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.45](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.44...antd-management-fast-framework@1.11.45) (2021-12-15)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.44](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.43...antd-management-fast-framework@1.11.44) (2021-12-14)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.43](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.42...antd-management-fast-framework@1.11.43) (2021-12-14)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.42](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.41...antd-management-fast-framework@1.11.42) (2021-12-14)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.41](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.40...antd-management-fast-framework@1.11.41) (2021-12-14)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.40](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.39...antd-management-fast-framework@1.11.40) (2021-12-14)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.39](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.38...antd-management-fast-framework@1.11.39) (2021-12-11)

### Performance Improvements

- update ([be8b7ef](https://github.com/kityandhero/antd-management-fast-framework/commit/be8b7efd6bce55a10949f635263d4769313f777f))

### [1.11.38](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.37...antd-management-fast-framework@1.11.38) (2021-12-11)

### Bug Fixes

- 修复一处错误 ([4b5cc90](https://github.com/kityandhero/antd-management-fast-framework/commit/4b5cc9053dc44e4f9e073489959e17720b9c92c0))

### [1.11.37](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.36...antd-management-fast-framework@1.11.37) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.36](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.35...antd-management-fast-framework@1.11.36) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.35](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.34...antd-management-fast-framework@1.11.35) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.34](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.33...antd-management-fast-framework@1.11.34) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.33](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.32...antd-management-fast-framework@1.11.33) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.32](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.31...antd-management-fast-framework@1.11.32) (2021-12-10)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.31](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.30...antd-management-fast-framework@1.11.31) (2021-12-09)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.30](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.29...antd-management-fast-framework@1.11.30) (2021-12-08)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.29](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.28...antd-management-fast-framework@1.11.29) (2021-12-07)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.28](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.27...antd-management-fast-framework@1.11.28) (2021-12-07)

### Performance Improvements

- update ([c462bc5](https://github.com/kityandhero/antd-management-fast-framework/commit/c462bc53593af73ea7c96d1d2b923c5414656588))

### [1.11.27](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.26...antd-management-fast-framework@1.11.27) (2021-12-07)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.26](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.25...antd-management-fast-framework@1.11.26) (2021-12-04)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.25](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.24...antd-management-fast-framework@1.11.25) (2021-12-04)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.24](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.23...antd-management-fast-framework@1.11.24) (2021-12-04)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.23](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.22...antd-management-fast-framework@1.11.23) (2021-12-04)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.22](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.21...antd-management-fast-framework@1.11.22) (2021-12-02)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.21](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.20...antd-management-fast-framework@1.11.21) (2021-12-02)

### Performance Improvements

- update ([730b6e1](https://github.com/kityandhero/antd-management-fast-framework/commit/730b6e1efb3fe9bebcde65b0c801405ca41b5c62))

### [1.11.20](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.19...antd-management-fast-framework@1.11.20) (2021-12-02)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.19](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.18...antd-management-fast-framework@1.11.19) (2021-12-01)

### Performance Improvements

- update ([48c5b3c](https://github.com/kityandhero/antd-management-fast-framework/commit/48c5b3ce4885532ebaea178c39235efd0905affc))

### [1.11.18](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.17...antd-management-fast-framework@1.11.18) (2021-12-01)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.17](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.16...antd-management-fast-framework@1.11.17) (2021-12-01)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.16](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.15...antd-management-fast-framework@1.11.16) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.15](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.14...antd-management-fast-framework@1.11.15) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.14](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.13...antd-management-fast-framework@1.11.14) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.13](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.12...antd-management-fast-framework@1.11.13) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.12](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.11...antd-management-fast-framework@1.11.12) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.11](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.10...antd-management-fast-framework@1.11.11) (2021-11-30)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.10](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.9...antd-management-fast-framework@1.11.10) (2021-11-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.9](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.8...antd-management-fast-framework@1.11.9) (2021-11-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.8](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.7...antd-management-fast-framework@1.11.8) (2021-11-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.7](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.6...antd-management-fast-framework@1.11.7) (2021-11-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.6](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.5...antd-management-fast-framework@1.11.6) (2021-11-29)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.5](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.4...antd-management-fast-framework@1.11.5) (2021-11-27)

**Note:** Version bump only for package antd-management-fast-framework

### [1.11.4](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.3...antd-management-fast-framework@1.11.4) (2021-11-27)

### Bug Fixes

- adjust nprocess behavior ([066b5bc](https://github.com/kityandhero/antd-management-fast-framework/commit/066b5bc72f20404be57cd85a8c86f186cf48ddcb))
- **antd-management-fast-framework:** 列表视图增加分页栏固定配置 ([3ed968a](https://github.com/kityandhero/antd-management-fast-framework/commit/3ed968a0704c562cdeecbe1934683e7e361ded47))

### [1.11.3](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.2...antd-management-fast-framework@1.11.3) (2021-11-26)

### Bug Fixes

- 调整配置 ([477f9ef](https://github.com/kityandhero/antd-management-fast-framework/commit/477f9ef91a106294287d95affc1b9df580cc738e))

### [1.11.2](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.1...antd-management-fast-framework@1.11.2) (2021-11-26)

### Bug Fixes

- 调整配置 ([1b1a24e](https://github.com/kityandhero/antd-management-fast-framework/commit/1b1a24e969c5c834d1d070b26bf522423e910ce7))

### [1.11.1](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.11.0...antd-management-fast-framework@1.11.1) (2021-11-26)

**Note:** Version bump only for package antd-management-fast-framework

## [1.11.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.10.0...antd-management-fast-framework@1.11.0) (2021-11-26)

### Features

- iconinfo 组件针对 eclipse 做出调整 ([02db4d7](https://github.com/kityandhero/antd-management-fast-framework/commit/02db4d7103a499da90de6659479c34d631b3abfd))

## [1.10.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.39...antd-management-fast-framework@1.10.0) (2021-11-26)

### Features

- 增加配置 ([c9e9798](https://github.com/kityandhero/antd-management-fast-framework/commit/c9e9798897931ca96eb61e0c0617a4c0447e3ecd))

### [1.9.39](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.38...antd-management-fast-framework@1.9.39) (2021-11-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.38](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.37...antd-management-fast-framework@1.9.38) (2021-11-24)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.37](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.36...antd-management-fast-framework@1.9.37) (2021-11-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.36](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.35...antd-management-fast-framework@1.9.36) (2021-11-23)

### Performance Improvements

- update ([94b54bd](https://github.com/kityandhero/antd-management-fast-framework/commit/94b54bd0417e8cdaa2df97c6cd53539a094bd903))

### [1.9.35](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.34...antd-management-fast-framework@1.9.35) (2021-11-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.34](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.33...antd-management-fast-framework@1.9.34) (2021-11-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.33](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.32...antd-management-fast-framework@1.9.33) (2021-11-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.32](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.31...antd-management-fast-framework@1.9.32) (2021-11-23)

### Performance Improvements

- update ([d2358e9](https://github.com/kityandhero/antd-management-fast-framework/commit/d2358e9cb9793cc9bac3f0da1582b808335e7570))

### [1.9.31](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.30...antd-management-fast-framework@1.9.31) (2021-11-23)

### Performance Improvements

- update ([524aca4](https://github.com/kityandhero/antd-management-fast-framework/commit/524aca45ed6da65b0e50127facd1f88a261b0cc0))

### [1.9.30](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.29...antd-management-fast-framework@1.9.30) (2021-11-23)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.29](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.28...antd-management-fast-framework@1.9.29) (2021-11-22)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.28](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.27...antd-management-fast-framework@1.9.28) (2021-11-22)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.27](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.26...antd-management-fast-framework@1.9.27) (2021-11-20)

### Performance Improvements

- update ([3599f1a](https://github.com/kityandhero/antd-management-fast-framework/commit/3599f1a727005497131671401e81f88cb66e05bb))

### [1.9.26](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.25...antd-management-fast-framework@1.9.26) (2021-11-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.25](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.24...antd-management-fast-framework@1.9.25) (2021-11-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.24](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.23...antd-management-fast-framework@1.9.24) (2021-11-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.23](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.22...antd-management-fast-framework@1.9.23) (2021-11-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.22](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.21...antd-management-fast-framework@1.9.22) (2021-11-20)

### Performance Improvements

- update ([95e6a5e](https://github.com/kityandhero/antd-management-fast-framework/commit/95e6a5ee34208ccce39533adb9618890a7100e26))

### [1.9.21](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.20...antd-management-fast-framework@1.9.21) (2021-11-20)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.20](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.19...antd-management-fast-framework@1.9.20) (2021-11-20)

### Performance Improvements

- update ([ea1b277](https://github.com/kityandhero/antd-management-fast-framework/commit/ea1b277520ccdac8f3f620b844100d64f61cef83))

### [1.9.19](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.18...antd-management-fast-framework@1.9.19) (2021-11-20)

### Performance Improvements

- update ([85362ee](https://github.com/kityandhero/antd-management-fast-framework/commit/85362ee5184000c60d9c2530e8d082253e32fa4f))

### [1.9.18](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.17...antd-management-fast-framework@1.9.18) (2021-11-19)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.17](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.16...antd-management-fast-framework@1.9.17) (2021-11-18)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.16](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.15...antd-management-fast-framework@1.9.16) (2021-11-18)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.15](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.14...antd-management-fast-framework@1.9.15) (2021-11-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.14](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.13...antd-management-fast-framework@1.9.14) (2021-11-16)

### Performance Improvements

- update ([0d473d3](https://github.com/kityandhero/antd-management-fast-framework/commit/0d473d3ae7b6f80e2617865dd9cf017c3a179465))

### [1.9.13](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.12...antd-management-fast-framework@1.9.13) (2021-11-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.12](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.11...antd-management-fast-framework@1.9.12) (2021-11-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.11](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.10...antd-management-fast-framework@1.9.11) (2021-11-16)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.10](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.10) (2021-11-15)

### Performance Improvements

- update ([52ca489](https://github.com/kityandhero/antd-management-fast-framework/commit/52ca4896825cbefdf9f06574b0b7f3065f5dd0d1))
- update ([610da1c](https://github.com/kityandhero/antd-management-fast-framework/commit/610da1c84276626915d1c525d5e834bdc56f7ed2))
- update ([7035e0b](https://github.com/kityandhero/antd-management-fast-framework/commit/7035e0bd1140b4d1521e2392847fb6156e76a478))
- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.9.9](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.9) (2021-11-15)

### Performance Improvements

- update ([7035e0b](https://github.com/kityandhero/antd-management-fast-framework/commit/7035e0bd1140b4d1521e2392847fb6156e76a478))
- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.9.8](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.8) (2021-11-15)

### Performance Improvements

- update ([b6f37bf](https://github.com/kityandhero/antd-management-fast-framework/commit/b6f37bfc29efd7003a6626614a566c8857d142bc))
- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.9.7](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.7) (2021-11-15)

### Performance Improvements

- update ([ecee886](https://github.com/kityandhero/antd-management-fast-framework/commit/ecee886aee338ffe0c9cdd87298a7d66fe726d75))
- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.9.6](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.6) (2021-11-15)

### Performance Improvements

- update ([5f0c977](https://github.com/kityandhero/antd-management-fast-framework/commit/5f0c97737e06c439e07d4be38f1087af19e63054))

### [1.9.5](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.4...antd-management-fast-framework@1.9.5) (2021-11-15)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.4](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.3...antd-management-fast-framework@1.9.4) (2021-11-13)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.3](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.2...antd-management-fast-framework@1.9.3) (2021-11-13)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.2](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.1...antd-management-fast-framework@1.9.2) (2021-11-13)

**Note:** Version bump only for package antd-management-fast-framework

### [1.9.1](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.9.0...antd-management-fast-framework@1.9.1) (2021-11-13)

**Note:** Version bump only for package antd-management-fast-framework

## [1.9.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.10...antd-management-fast-framework@1.9.0) (2021-11-12)

### Features

- update ([ebdabe0](https://github.com/kityandhero/antd-management-fast-framework/commit/ebdabe08c787760e8efea35f1a1148985749f7f4))

### [1.8.10](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.9...antd-management-fast-framework@1.8.10) (2021-11-09)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.9](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.8...antd-management-fast-framework@1.8.9) (2021-11-09)

### Bug Fixes

- 调整显示 ([c5f4cc1](https://github.com/kityandhero/antd-management-fast-framework/commit/c5f4cc1ad460648b708ff2ed28a5ad6bbcd7c1af))

### [1.8.8](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.7...antd-management-fast-framework@1.8.8) (2021-11-09)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.7](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.6...antd-management-fast-framework@1.8.7) (2021-11-06)

### Bug Fixes

- adjust corsTargetWithApiVersion function ([e465e1e](https://github.com/kityandhero/antd-management-fast-framework/commit/e465e1e1db0102a2bc104d31ac5254d264c2974c))

### [1.8.6](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.5...antd-management-fast-framework@1.8.6) (2021-11-06)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.5](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.4...antd-management-fast-framework@1.8.5) (2021-11-03)

### Bug Fixes

- **antd-management-fast-framework:** 修复缺失的 import ([3daa3c9](https://github.com/kityandhero/antd-management-fast-framework/commit/3daa3c94c9d51aebf566bf2d1aa6d96a120c7746))

### [1.8.4](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.3...antd-management-fast-framework@1.8.4) (2021-11-02)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.3](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.2...antd-management-fast-framework@1.8.3) (2021-11-02)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.2](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.1...antd-management-fast-framework@1.8.2) (2021-11-02)

**Note:** Version bump only for package antd-management-fast-framework

### [1.8.1](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.8.0...antd-management-fast-framework@1.8.1) (2021-11-02)

**Note:** Version bump only for package antd-management-fast-framework

## [1.8.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.8.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.7.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.7.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.6.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.6.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

## [1.5.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.5.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

# [1.4.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.4.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

# [1.3.0](https://github.com/kityandhero/antd-management-fast-framework/compare/antd-management-fast-framework@1.2.61...antd-management-fast-framework@1.3.0) (2021-11-02)

### Features

- **antd-management-fast-framework:** update ([30b75d5](https://github.com/kityandhero/antd-management-fast-framework/commit/30b75d5082c1f5a63e17160ea716b2bdbf2d5742))

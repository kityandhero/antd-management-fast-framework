# antd-management-fast-framework

[![NPM version](https://img.shields.io/npm/v/antd-management-fast-framework.svg?style=flat)](https://npmjs.org/package/antd-management-fast-framework) [![NPM downloads](http://img.shields.io/npm/dm/antd-management-fast-framework.svg?style=flat)](https://npmjs.org/package/antd-management-fast-framework)

everyone

## Install

```bash
# or yarn
$ npm install
```

```bash
$ npm run build --watch
$ npm run start
```

## Usage

Configure in `.umirc.js`,

```js
export default {
  plugins: [['antd-management-fast-framework']],
};
```

## Options

TODO

## LICENSE

MIT

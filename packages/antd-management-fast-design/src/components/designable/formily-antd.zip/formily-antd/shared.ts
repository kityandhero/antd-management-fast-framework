import { Engine, TreeNode } from '@designable/core';

export type ComponentNameMatcher =
  | string
  | string[]
  | ((
      name: string,
      node: TreeNode | undefined | null,
      context?: any,
    ) => boolean);

export const matchComponent = (
  node: TreeNode | undefined | null,
  name: ComponentNameMatcher,
  context?: any,
) => {
  if (name === '*') return true;
  const componentName = node?.props?.['x-component'];
  if (typeof name === 'function')
    return name(componentName || '', node, context);
  if (Array.isArray(name)) return name.includes(componentName);
  return componentName === name;
};

export const matchChildComponent = (
  node: TreeNode,
  name: ComponentNameMatcher,
  context?: any,
) => {
  if (name === '*') return true;
  const componentName = node?.props?.['x-component'];
  if (!componentName) return false;
  if (typeof name === 'function')
    return name(componentName || '', node, context);
  if (Array.isArray(name)) return name.includes(componentName);
  return componentName.includes(`${name}.`);
};

export const includesComponent = (
  node: TreeNode,
  names: ComponentNameMatcher[],
  target?: TreeNode,
) => {
  return names.some((name) => matchComponent(node, name, target));
};

export const queryNodesByComponentPath = (
  node: TreeNode | undefined | null,
  path: ComponentNameMatcher[],
): TreeNode[] => {
  if (path?.length === 0) return [];
  if (path?.length === 1 && node && matchComponent(node, path[0])) {
    return [node];
  }
  return matchComponent(node, path[0])
    ? node?.children.reduce((buf, child) => {
        return buf.concat(queryNodesByComponentPath(child, path.slice(1)));
      }, [])
    : [];
};

export const findNodeByComponentPath = (
  node: TreeNode | undefined | null,
  path: ComponentNameMatcher[],
): TreeNode | undefined | null => {
  if (path?.length === 0) return;
  if (path?.length === 1 && matchComponent(node, path[0])) {
    return node;
  }
  if (matchComponent(node, path[0])) {
    for (let index = 0; index < (node?.children?.length || 0); index++) {
      const next = findNodeByComponentPath(
        node?.children[index],
        path.slice(1),
      );
      if (next) {
        return next;
      }
    }
  }
};

export const hasNodeByComponentPath = (
  node: TreeNode | undefined | null,
  path: ComponentNameMatcher[],
) => !!findNodeByComponentPath(node, path);

export const matchArrayItemsNode = (node: TreeNode) => {
  return (
    node?.parent?.props?.type === 'array' &&
    node?.parent?.children?.[0] === node
  );
};

export const createNodeId = (designer: Engine, id: string) => {
  return {
    [designer.props.nodeIdAttrName]: id,
  };
};

export const createEnsureTypeItemsNode =
  (type: string) => (node?: TreeNode | undefined | null) => {
    const objectNode = node?.children.find(
      (child) => child.props?.['type'] === type,
    );
    if (objectNode) {
      return objectNode;
    } else {
      const newObjectNode = new TreeNode({
        componentName: 'Field',
        props: {
          type,
        },
      });
      node?.prepend(newObjectNode);
      return newObjectNode;
    }
  };

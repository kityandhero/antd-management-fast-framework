/**
 * 占位函数
 *
 * @export
 * @returns
 */
export function empty() {
  return {};
}

import BaseLoadModal from '../BaseLoadModal';

class BaseUpdateModal extends BaseLoadModal {}

export default BaseUpdateModal;

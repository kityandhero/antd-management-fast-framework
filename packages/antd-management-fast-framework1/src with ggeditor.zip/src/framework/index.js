// export { default as Base } from './Base';
// export { default as AuthorizationWrapper } from './AuthorizationWrapper';
// export { default as SelectButtonBase } from './ButtonExtension/SelectButton/Base';
// export { default as SelectButtonInteractiveBase } from './ButtonExtension/SelectButton/InteractiveBase';
// export { default as Common } from './Common';
// export { default as Core } from './Core';
// export { default as CustomBase } from './CustomBase';
// export { default as CustomWrapperSupplement } from './CustomWrapper/Supplement';
// export { default as CustomWrapperSupplementCore } from './CustomWrapper/SupplementCore';
// export { default as CustomWrapperSupplementWrapper } from './CustomWrapper/SupplementWrapper';
// export { default as DataDrawerBase } from './DataDrawer/Base';
// export { default as BaseAddDrawer } from './DataDrawer/BaseAddDrawer';
// export { default as BaseLoadDrawer } from './DataDrawer/BaseLoadDrawer';
// export { default as BaseSaveDrawer } from './DataDrawer/BaseSaveDrawer';
// export { default as BaseUpdateDrawer } from './DataDrawer/BaseUpdateDrawer';
// export { default as BaseAddForm } from './DataForm/BaseAddForm';
// export { default as BaseUpdateForm } from './DataForm/BaseUpdateForm';
// export { default as BaseUpdateFormTab } from './DataForm/BaseUpdateFormTab';
// export { default as DataListViewBase } from './DataListView/Base';
// export { default as DataListBatchAction } from './DataListView/BatchAction';
// export { default as DataListColumnSetting } from './DataListView/ColumnSetting';
// export { default as DataListColumnSettingDndItem } from './DataListView/ColumnSetting/DndItem';
// export { default as DataListDensityAction } from './DataListView/DensityAction';
// export { default as DataModalBase } from './DataModal/Base';
// export { default as BaseAddModal } from './DataModal/BaseAddModal';
// export { default as BaseLoadModal } from './DataModal/BaseLoadModal';
// export { default as BaseSelectModal } from './DataModal/BaseSelectModal';
// export { default as BaseUpdateModal } from './DataModal/BaseUpdateModal';
// export { default as InnerMultiPage } from './DataMultiPageView/InnerMultiPage';
// export { default as MultiPage } from './DataMultiPageView/MultiPage';
// export { default as MultiPageDrawer } from './DataMultiPageView/MultiPageDrawer';
// export { default as DataOperationBase } from './DataOperation/Base';
// export { default as BaseView } from './DataOperation/BaseView';
// export { default as BaseWindow } from './DataOperation/BaseWindow';
// export { default as InnerSinglePage } from './DataSinglePageView/InnerSinglePage';
// export { default as SinglePage } from './DataSinglePageView/SinglePage';
// export { default as SinglePageDrawer } from './DataSinglePageView/SinglePageDrawer';
// export { default as DataSingleViewCore } from './DataSingleView/DataCore';
// export { default as DataSingleViewLoad } from './DataSingleView/DataLoad';
// export { default as DataTabContainer } from './DataTabContainer';
// export { default as SelectFieldBase } from './FieldExtension/SelectFieldDrawer/SelectFieldBase';
// export { default as SelectFieldDrawerBase } from './FieldExtension/SelectFieldDrawer/SelectFieldDrawerBase';
// export { default as Wrapper } from './Wrapper';

/**
 * 占位函数
 *
 * @export
 * @returns
 */
export function empty() {
  return {};
}

import BaseUpdateFormContent from '../BaseUpdateFormContent';

class BaseUpdateFormTab extends BaseUpdateFormContent {}

export default BaseUpdateFormTab;

export function render(oldRender) {
  oldRender();
}
